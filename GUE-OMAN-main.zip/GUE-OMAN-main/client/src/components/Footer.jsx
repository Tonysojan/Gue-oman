import React from 'react'

function Footer()
{
  return (
    <>
        <div class="footer">
            <p>
                Copyright @ 2023 by Albin & Tony. All Rights Reserved.
                GUE Oman is Powered by Camerinfolks  Pvt Ltd.
            </p>
        </div>
    </>
  )
}

export default Footer;
