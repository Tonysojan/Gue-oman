import slide from '../images/Home.png'
function Home(){
    return(
        <>
        
        <img src={slide} className="slideimg" alt='Home'/>
        
        </>
    );
}
export default Home;