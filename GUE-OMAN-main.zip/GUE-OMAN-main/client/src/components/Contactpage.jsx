function Contact(){
    return(
        <>
      
        <center>
        <div className='body'>
        <div className="container"><br></br>
        
        <div className="left"></div>
            <div className="center">
            <br></br><br></br><br></br>
            <h2><b>Contact Us</b></h2><br></br>
            <h4>Address: 165/Al Jawdha Street, SANAYA, Salalah 211, Oman <br></br>
            Phone: +968 23 211626
            </h4>
            <br></br><br></br><br></br>
            </div>
            <div className='right'>
            {/* width="400" height="300"  allowfullscreen="" loading="lazy"  style="border:0;"referrerpolicy="no-referrer-when-downgrade" */}
            <iframe title="Map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3815.109774875506!2d54.05228651466519!3d17.018284688300767!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3dd16077b3ec2857%3A0xa492134a53317f65!2sGlobal%20united%20enterprises!5e0!3m2!1sen!2sin!4v1677394879032!5m2!1sen!2sin"></iframe>
            </div>
            </div></div>
            </center>
        </>
    );
}
export default Contact;